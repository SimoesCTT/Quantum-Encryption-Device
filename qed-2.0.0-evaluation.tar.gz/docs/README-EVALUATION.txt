QED EVALUATION VERSION - 30 DAY TRIAL
This version expires 30 days after compilation.
Commercial license required: https://paypal.me/amexsimoes/2000
Contact: amexsimoes@gmail.com
